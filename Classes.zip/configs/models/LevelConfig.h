﻿#pragma once
#include <vector>

// 花色类型
enum CardSuitType
{
    CST_NONE = -1,
    CST_CLUBS,      // 梅花
    CST_DIAMONDS,   // 方块
    CST_HEARTS,     // 红桃
    CST_SPADES,     // 黑桃
    CST_NUM_CARD_SUIT_TYPES
};

// 正面类型
enum CardFaceType
{
    CFT_NONE = -1,
    CFT_ACE,
    CFT_TWO,
    CFT_THREE,
    CFT_FOUR,
    CFT_FIVE,
    CFT_SIX,
    CFT_SEVEN,
    CFT_EIGHT,
    CFT_NINE,
    CFT_TEN,
    CFT_JACK,
    CFT_QUEEN,
    CFT_KING,
    CFT_NUM_CARD_FACE_TYPES
};

/// @brief 表示一个卡牌在关卡中的初始布局信息
struct CardLayout {
    CardFaceType cardFace;  // 0~12 (A-K)
    CardSuitType cardSuit;  // 3=♠, 2=♥, 1=♦, 0=♣
    float x;
    float y;
    bool faceUp;   // 补充字段（如果你后续用得到）
};

/// @brief 静态关卡配置
class LevelConfig {
public:
    int levelId;                                ///< 关卡ID
    std::vector<CardLayout> playfieldCards;
    std::vector<CardLayout> stackCards;

    LevelConfig(int id) : levelId(id) {}
};