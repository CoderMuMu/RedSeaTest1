﻿#include "LevelConfigLoader.h"
#include "cocos2d.h"
#include "json/document.h"
#include "json/filereadstream.h"

USING_NS_CC;
using namespace rapidjson;

LevelConfig LevelConfigLoader::loadLevelConfig(int levelId) {
    LevelConfig config(levelId);

    // Read the JSON file
    std::string path = StringUtils::format("LevelConfigs/level%d.json", levelId);
    std::string fullPath = cocos2d::FileUtils::getInstance()->fullPathForFilename(path);
    if (fullPath.empty()) {
        CCLOG("Load Level Config File Fail!");
    }

    std::string fileData = FileUtils::getInstance()->getStringFromFile(path);

    Document doc;
    doc.Parse(fileData.c_str());

    if (doc.HasParseError()) {
        CCLOG("JSON Parse Error");
        return config;
    }

    // 解析 Playfield 部分
    const auto& playfield = doc["Playfield"];
    for (SizeType i = 0; i < playfield.Size(); ++i) {
        const auto& cardJson = playfield[i];
        CardLayout card;
        card.cardFace = static_cast<CardFaceType>(cardJson["CardFace"].GetInt());
        card.cardSuit = static_cast<CardSuitType>(cardJson["CardSuit"].GetInt());
        card.x = cardJson["Position"]["x"].GetFloat();
        card.y = cardJson["Position"]["y"].GetFloat();
        card.faceUp = true;  // 可选字段：默认翻开
        config.playfieldCards.push_back(card);
    }

    // 解析 Stack 部分
    const auto& stack = doc["Stack"];
    for (SizeType i = 0; i < stack.Size(); ++i) {
        const auto& cardJson = stack[i];
        CardLayout card;
        card.cardFace = static_cast<CardFaceType>(cardJson["CardFace"].GetInt());
        card.cardSuit = static_cast<CardSuitType>(cardJson["CardSuit"].GetInt());
        card.x = cardJson["Position"]["x"].GetFloat();
        card.y = cardJson["Position"]["y"].GetFloat();
        card.faceUp = false;  // 抽牌堆默认是背面朝上
        config.stackCards.push_back(card);
    }

    return config;
}