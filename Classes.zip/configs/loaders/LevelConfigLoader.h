﻿#pragma once
#include "configs/models/LevelConfig.h"
#include <string>

/// @brief 加载关卡配置的工具
class LevelConfigLoader {
public:
    static LevelConfig loadLevelConfig(int levelId);
};