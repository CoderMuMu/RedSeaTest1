﻿#include "UndoManager.h"
#include "controllers/GameController.h"

USING_NS_CC;

bool UndoManager::init() {
	while (!_undoStack.empty()) _undoStack.pop();
	
	return true;
}

void UndoManager::pushState(CardModel* card, CardView* view, CardModel* top) {
    UndoData state;
    state.cardId = card->getUid();
    state.faceUp = card->getFaceUp();
    state.model = card;
    state.cardView = view;
    state.previousPosition = view->getPosition();
    state.previousLayer = view->getParent()->getName();
    state.previousTopCard = top;

    _undoStack.push(state);
}

void UndoManager::undo() {
    if (_undoStack.empty()) {
        CCLOG("undo: undoStack is empty");
        return;
    }

    UndoData last = _undoStack.top();
    _undoStack.pop();

    last.model->setFaceUp(last.faceUp);
    last.model->setIsMatched(false);
    GameController::getStackController()->updateCurrentCard(last.previousTopCard);

    if (last.previousLayer == "stackLayer") {
        
        GameController::getStackController()->undoStackCard(last.model, last.cardView);
        // 移动回原本位置
        last.cardView->runAction(Sequence::create(
            MoveTo::create(0.3f, last.previousPosition),
            CallFunc::create([=]() {
                last.cardView->setZOrder(last.model->getZOrder());
            }),
            nullptr
        ));
    }
    else {
        GameController::getPlayFieldController()->undoPlayFieldCard(last.model, last.cardView);
        // 移动回原本位置
        auto playFieldLayer = GameController::getGameView()->getPlayFieldLayer();
        auto stackLayer = GameController::getGameView()->getStackLayer();

        // 1. 先计算目标位置
        Vec2 targetLocalPos = last.previousPosition;
        Vec2 targetWorldPos = playFieldLayer->convertToWorldSpace(targetLocalPos);
        Vec2 moveToPos = last.cardView->getParent()->convertToNodeSpace(targetWorldPos);

        // 2. 先播放动画（仍在原父节点）
        last.cardView->runAction(Sequence::create(
            MoveTo::create(0.3f, moveToPos),
            CallFunc::create([=]() {
                // 3. 动画结束后，再切换父节点
                Vec2 finalWorldPos = last.cardView->getParent()->convertToWorldSpace(last.cardView->getPosition());
                last.cardView->retain(); // 防止销毁
                last.cardView->removeFromParentAndCleanup(false);

                Vec2 newLocalPos = playFieldLayer->convertToNodeSpace(finalWorldPos);
                last.cardView->setPosition(newLocalPos);
                playFieldLayer->addChild(last.cardView, last.model->getZOrder()); // 保证在最上层
                last.cardView->release();
                last.cardView->enableHoverEffect(true);
                }),
            nullptr
        ));
        
    }
}
