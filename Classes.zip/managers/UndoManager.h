﻿#pragma once
#include <stack>
#include "models/CardModel.h"
#include "views/CardView.h"
#include "cocos2d.h"

/// @brief 用于记录一次操作前的状态
struct UndoData {
    int cardId;                     // 被移动/匹配的卡牌 ID
    bool faceUp;                    // 是否面向上
    CardModel* model;               // 卡牌模型数据
    CardView* cardView;             // 卡牌视图（sprite)
    cocos2d::Vec2 previousPosition; // 移动前位置
    std::string previousLayer;      // 移动前的区域
    CardModel* previousTopCard;     // 当前手牌顶部卡牌

};

/// @brief 撤销管理器，存储历史记录
class UndoManager {
public:
    bool init();
    // 储存当前卡牌操作状态
    void pushState(CardModel* model, CardView* view, CardModel* top);
    /// 执行撤销操作
    void undo();
    
private:
    std::stack<UndoData> _undoStack;
};