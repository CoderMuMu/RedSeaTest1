﻿#include "GameModelFromLevelGenerator.h"

GameModel* GameModelFromLevelGenerator::generateGameModel(const LevelConfig& config) {
    GameModel* model = new GameModel();

    int cardId = 0;

    // 转换 Playfield
    for (const auto& layout : config.playfieldCards) {
        CardModel card(
            cardId++,
            layout.cardFace,
            layout.cardSuit,
            layout.x,
            layout.y,
            layout.faceUp,
            false);

        model->playfieldCards.push_back(card);
    }

    // 转换 Stack
    for (const auto& layout : config.stackCards) {
        CardModel card(
            cardId++,
            layout.cardFace,
            layout.cardSuit,
            layout.x,
            layout.y,
            layout.faceUp,
            false);

        model->stackCards.push_back(card);
    }

    return model;
}
