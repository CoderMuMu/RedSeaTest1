﻿#pragma once
#include "models/GameModel.h"
#include "configs/models/LevelConfig.h"

/// @brief 将静态关卡配置转换为运行时数据 GameModel
class GameModelFromLevelGenerator {
public:
    static GameModel* generateGameModel(const LevelConfig& levelConfig);
};