﻿#pragma once

#include "configs/models/LevelConfig.h"
#include "cocos2d.h"
#include <set>

/// @brief 表示一张卡牌的数据模型
class CardModel {
private:
    int _id;                    // 唯一 ID
    CardFaceType _face;         // 点数
    CardSuitType _suit;         // 花色
    float _x, _y;               // 初始位置
    bool _faceUp;               // 是否翻面
    bool _isMatched;            // 是否已被消除
    cocos2d::Rect _boundingBox; // 实体框对象
    int _zOrder;                // 层级
public:
    CardModel(int id, CardFaceType face, CardSuitType suit, float x, float y, bool faceUp,
        bool isMatched) : _id(id), _face(face), _suit(suit),
        _x(x), _y(y), _faceUp(faceUp), _isMatched(isMatched){}

    int getUid() const noexcept { return _id; }
    CardFaceType getFace() const noexcept { return _face; }
    CardSuitType getSuit() const noexcept { return _suit; }
    cocos2d::Vec2 getPosition() const { return cocos2d::Vec2(_x,_y); }
    bool getFaceUp() const { return _faceUp; }
    bool getIsMatched() const { return _isMatched; }
    cocos2d::Rect getBoundingBox() const { return _boundingBox; }
    int getZOrder() const { return _zOrder; }

    void setFaceUp(const bool faceUp) { _faceUp = faceUp; }
    void setIsMatched(const bool isMatched) { _isMatched = isMatched; }
    void setBoundingBox(const cocos2d::Rect& boundingBox) { _boundingBox = boundingBox; }
    void setZOrder(const int order) { _zOrder = order; }

    std::set<CardModel*> coverBy;
    std::set<CardModel*> covered;
};