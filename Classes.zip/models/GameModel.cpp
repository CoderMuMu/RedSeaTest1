﻿#include "GameModel.h"


USING_NS_CC;


GameModel::GameModel()
{
    playfieldCards.clear();
    stackCards.clear();
}
