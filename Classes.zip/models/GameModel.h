﻿#pragma once
#include <vector>
#include "CardModel.h"
#include "cocos2d.h"

/// @brief 整个关卡运行时模型，包含场上卡牌和抽牌堆
class GameModel {
public:
    std::vector<CardModel> playfieldCards;
    std::vector<CardModel> stackCards;
    GameModel();
};