﻿#pragma once
#include "cocos2d.h"
#include "models/CardModel.h"

/// @brief 卡牌视图类，负责展示单张卡牌的UI及交互效果（如点击、悬停动画）
///
/// 功能：
/// - 从模型 CardModel 构建卡牌视图
/// - 支持点击反馈、悬停放大、匹配动画等
/// 使用场景：
/// - 用于 GameView 中的 playfield 或 stack 区域，显示并控制卡牌状态
class CardView : public cocos2d::Sprite {
public:
    // 从卡牌数据模型创建卡牌视图
    static CardView* createFromModel(const CardModel& model);
    
    //初始化
    bool init(const CardModel& model);
    
    // 获得卡牌Id
    int getCardId() const { return _cardId; }

    // 加载图层资源
    void loadCardGraphics(CardFaceType face, CardSuitType suit);
    
    // 特效
    void enableHoverEffect(bool enable);
    void setHighlight(bool isHighlighted);

private:
    int _cardId = -1;              
    bool _hoverEnabled = false;     // 是否启用特效
    bool _isHighlighted = false;
    cocos2d::EventListenerMouse* _hoverListener;
};
