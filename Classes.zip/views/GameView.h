﻿#pragma once

#include "CardView.h"
#include "cocos2d.h"


///  @brief 游戏主界面的可视化呈现
class GameView : public cocos2d::Scene {
public:
    static GameView* createScene();

    virtual bool init();

    // implement the "static create()" method manually
    CREATE_FUNC(GameView);

    cocos2d::Layer* getPlayFieldLayer() const { return _playfieldLayer; }
    cocos2d::Layer* getStackLayer() const { return _stackLayer; }

    void setUndoCallback(cocos2d::Ref* pSender);
private:
    cocos2d::Layer* _playfieldLayer = nullptr;
    cocos2d::Layer* _stackLayer = nullptr;

};