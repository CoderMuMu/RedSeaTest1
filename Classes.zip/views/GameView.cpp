﻿#include "GameView.h"
#include "controllers/GameController.h"

USING_NS_CC;

GameView* GameView::createScene()
{
    return GameView::create();
}


bool GameView::init()
{
    // 1. super init first
    if (!Scene::init())
        return false;

    const auto visibleSize = Director::getInstance()->getVisibleSize();
    const Vec2 origin = Director::getInstance()->getVisibleOrigin();

    // Playfield Layer
    _playfieldLayer = Layer::create();
    _playfieldLayer->setName("playFieldLayer");
    _playfieldLayer->setContentSize(Size(visibleSize.width, visibleSize.height * 0.7f));
    _playfieldLayer->setPosition(origin.x, origin.y + visibleSize.height * 0.3f);
    this->addChild(_playfieldLayer, -1);

    // Stack Layer
    _stackLayer = Layer::create();
    _stackLayer->setName("stackLayer");
    _stackLayer->setContentSize(Size(visibleSize.width, visibleSize.height * 0.3f));
    _stackLayer->setPosition(origin);
    this->addChild(_stackLayer, -1);

    // 背景颜色
    auto playBG = LayerColor::create(Color4B(249, 192, 78, 255),
        _playfieldLayer->getContentSize().width,
        _playfieldLayer->getContentSize().height);
    _playfieldLayer->addChild(playBG);

    auto stackBG = LayerColor::create(Color4B(194, 252, 255, 255),
        _stackLayer->getContentSize().width,
        _stackLayer->getContentSize().height);
    _stackLayer->addChild(stackBG);

    // 创建 Undo 按钮
    auto undoLabel = Label::createWithTTF("Undo", "fonts/Marker Felt.ttf", 50);
    auto undoItem = MenuItemLabel::create(
        undoLabel, 
        CC_CALLBACK_1(GameView::setUndoCallback, this));
    if (undoItem == nullptr) {
        CCLOG("undoItem register fail");
    }
    else {
        undoItem->setPosition(Vec2(
            _stackLayer->getContentSize().width * 0.9,
            _stackLayer->getContentSize().height * 0.5)); 
    }
    auto menu = Menu::create(undoItem, nullptr);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu);

    return true;
}

void GameView::setUndoCallback(cocos2d::Ref* pSender) {
    CCLOG("check");
    GameController::handleUndo();
}
