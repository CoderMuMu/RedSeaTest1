﻿#include "CardView.h"
#include "configs/models/CardResConfig.h"

USING_NS_CC;


CardView* CardView::createFromModel(const CardModel& model)
{
	auto card = new(std::nothrow) CardView();
    if (card && card->init(model)) {
        card->autorelease();
        return card;
    }
    delete card;
    return nullptr;
}

bool CardView::init(const CardModel& model) {
    if (!Sprite::initWithFile("res/card_general.png")) {
        printf("Card General init fail!\n");
        return false;
    }

    _cardId = model.getUid();
    setAnchorPoint(Vec2(0.5f, 0.5f));

    // 加载图层资源
    loadCardGraphics(model.getFace(), model.getSuit());

    return true;
}

void CardView::loadCardGraphics(CardFaceType face, CardSuitType suit)
{
    std::string suitRes, centerRes, cornerRes;
    CardResConfig::getCardRes(face, suit, suitRes, centerRes, cornerRes);

    auto suitSprite = Sprite::create(suitRes);
    if (suitSprite) {
        suitSprite->setPosition(Vec2(140, 240));
        this->addChild(suitSprite);
    }

    auto centerSprite = Sprite::create(centerRes);
    if (centerSprite) {
        centerSprite->setPosition(Vec2(90, 120));
        this->addChild(centerSprite);
    }

    auto cornerSprite = Sprite::create(cornerRes);
    if (cornerSprite) {
        cornerSprite->setPosition(Vec2(30, 240));
        this->addChild(cornerSprite);
    }
}

void CardView::enableHoverEffect(bool enable) {
    _hoverEnabled = enable;

    // 若已存在监听器，先移除
    if (_hoverListener) {
        _eventDispatcher->removeEventListener(_hoverListener);
        _hoverListener = nullptr;
    }

    // 若启用，重新注册监听
    if (enable) {
        _hoverListener = cocos2d::EventListenerMouse::create();
        _hoverListener->onMouseMove = [=](cocos2d::EventMouse* event) {
            auto locationInNode = this->convertToNodeSpace(event->getLocationInView());
            auto size = this->getContentSize();
            cocos2d::Rect rect(0, 0, size.width, size.height);

            if (rect.containsPoint(locationInNode)) {
                setHighlight(true);
            }
            else {
                setHighlight(false);
            }
        };
        _eventDispatcher->addEventListenerWithSceneGraphPriority(_hoverListener, this);
    }
}


void CardView::setHighlight(bool isHighlighted) {
    if (!_hoverEnabled) return;

    if (_isHighlighted == isHighlighted) return; // 避免重复执行
    _isHighlighted = isHighlighted;

    this->stopAllActions();
    if (isHighlighted) {
        this->runAction(cocos2d::ScaleTo::create(0.1f, 1.1f)); // 悬停放大
    }
    else {
        this->runAction(cocos2d::ScaleTo::create(0.1f, 1.0f)); // 离开还原
    }
}