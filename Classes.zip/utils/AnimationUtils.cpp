#include "AnimationUtils.h"

cocos2d::Action* AnimationUtils::createShakeAction(float duration, float strength) {
    return cocos2d::Sequence::create(
        cocos2d::MoveBy::create(0.02f, cocos2d::Vec2(strength, 0)),
        cocos2d::MoveBy::create(0.02f, cocos2d::Vec2(-strength * 2, 0)),
        cocos2d::MoveBy::create(0.02f, cocos2d::Vec2(strength * 2, 0)),
        cocos2d::MoveBy::create(0.02f, cocos2d::Vec2(-strength * 2, 0)),
        cocos2d::MoveBy::create(0.02f, cocos2d::Vec2(strength, 0)),
        nullptr
    );
}