﻿#pragma once
#include "cocos2d.h"

class AnimationUtils {
public:
    /// 创建一个左右震动动画，用于反馈不可操作的卡片
    static cocos2d::Action* createShakeAction(float duration = 0.2f, float strength = 10.0f);
};