#include "CardMatchUtil.h"

USING_NS_CC;

bool CardMatchUtil::canMatch(const CardModel& model, const CardModel& topStack)
{
	const auto below = (topStack.getFace() == CFT_ACE) ? CFT_KING : topStack.getFace() - 1;
	const auto up = (topStack.getFace() == CFT_KING) ? CFT_ACE : topStack.getFace() + 1;

	if (model.getFace() == below || model.getFace() == up)
		return true;
	return false;
}