#pragma once

#include "cocos2d.h"
#include "models/CardModel.h"

class CardMatchUtil {
public:
	static bool canMatch(const CardModel& model, const CardModel& topStack);
};