﻿#pragma once
#include "models/GameModel.h"
#include "views/GameView.h"
#include "managers/UndoManager.h"
#include "PlayFieldController.h"
#include "StackController.h"
#include "services/GameModelFromLevelGenerator.h"
#include "cocos2d.h"

/// @brief 控制游戏主流程
class GameController {
public:
    
    static GameController* create();
    bool init();

    // 启动游戏，加载关卡配置
    static void startGame(int levelId);

    static StackController* getStackController();
    static PlayFieldController* getPlayFieldController();
    static GameView* getGameView();
    
    // 设置点击卡牌回调函数
    static void handlePlayFieldCardClick(int cardId);
    static void handleStackCardClick(int cardId);
    // 设置 Undo 按钮回调函数
    static void handleUndo();
    // 检查游戏状态
    static void checkGameProgress();
    
private:
    static GameModel* _gameModel;
    static GameView* _gameView;
    static UndoManager* _undoManager;
    static PlayFieldController* _playFieldController;
    static StackController* _stackController;
};