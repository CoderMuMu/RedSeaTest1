﻿#include "GameController.h"
#include "configs/loaders/LevelConfigLoader.h"
#include "services/GameModelFromLevelGenerator.h"

USING_NS_CC;

GameModel* GameController::_gameModel = nullptr;
GameView* GameController::_gameView = nullptr;
UndoManager* GameController::_undoManager = nullptr;
PlayFieldController* GameController::_playFieldController = nullptr;
StackController* GameController::_stackController = nullptr;

GameController* GameController::create() {
    GameController* controller = new(std::nothrow) GameController();
    if (controller && controller->init()) {
        return controller;
    }
    else
    {
        delete controller;
        controller = nullptr;
        return nullptr;
    }
}

bool GameController::init() {
    
    _gameModel = new GameModel();
    _gameView  = new GameView();
    _undoManager = new UndoManager();
    _playFieldController = new PlayFieldController();
    _stackController = new StackController();
    return true;
}

void GameController::startGame(int levelId) {
    // Step 1: 加载配置
    LevelConfig config = LevelConfigLoader::loadLevelConfig(levelId);

    // Step 2: 构建数据模型
    _gameModel = GameModelFromLevelGenerator::generateGameModel(config);

    // Step 3: 初始化控制器
    _playFieldController->init(_gameModel->playfieldCards);
    _stackController->init(_gameModel->stackCards);
    _undoManager->init();

    // Step 4: 创建并初始化 GameView
    _gameView = GameView::createScene();
    auto director = Director::getInstance();
    director->replaceScene((Scene*)_gameView);

    // Step 5: 控制器设置视图
    if (!_stackController->initView(_gameView->getStackLayer())) {
        CCLOG("Stack Init View Fail!");
    }
    if (!_playFieldController->initView(_gameView->getPlayFieldLayer())) {
        CCLOG("Playfield Init View Fail!");
    }
    
}

StackController* GameController::getStackController()
{
    return _stackController;
}

PlayFieldController* GameController::getPlayFieldController()
{
    return _playFieldController;
}

GameView* GameController::getGameView()
{
    return _gameView;
}

void GameController::handlePlayFieldCardClick(int cardId) 
{
    _playFieldController->onCardClick(cardId, _gameView, _undoManager);
}

void GameController::handleStackCardClick(int cardId) 
{
    _stackController->drawNextCard(cardId, _gameView, _undoManager);
}

void GameController::handleUndo() 
{
    _undoManager->undo();
}

void GameController::checkGameProgress()
{
    // 关卡胜利

}