﻿#include "PlayFieldController.h"
#include "models/GameModel.h"
#include "models/CardModel.h"
#include "GameController.h"
#include "utils/CardMatchUtil.h"
#include "utils/AnimationUtils.h"

USING_NS_CC;

bool PlayFieldController::init(const std::vector<CardModel>& playFieldCards) {
    _playFieldCards = playFieldCards;  
    hasMovedCount = 0;
    // 初始化内部状态，如布局等
    for (const auto& card : _playFieldCards) {
        CCLOG("Init Playfield Card: id=%d, face=%d, suit=%d", card.getUid(), card.getFace(), card.getSuit());
    }

    return true;
}


bool PlayFieldController::initView(cocos2d::Node* playFieldLayer)
{
    if (!playFieldLayer || _playFieldCards.empty()) {
        CCLOG("Playfield Init View Fail!");
        return false;
    }

    int order = 1;
    for (auto& cardModel : _playFieldCards) {
        // 创建卡牌视图
        auto cardView = CardView::createFromModel(cardModel);
        cardView->setPosition(cardModel.getPosition());
        cardView->setTag(cardModel.getUid());

        // 设置 bounding box
        cardModel.setBoundingBox(cardView->getBoundingBox());

        // 注册点击事件
        auto listener = EventListenerTouchOneByOne::create();
        listener->setSwallowTouches(true);

        listener->onTouchBegan = [=](Touch* touch, Event* event) {
            auto locationInNode = cardView->convertToNodeSpace(touch->getLocation());
            auto size = cardView->getContentSize();
            Rect rect(0, 0, size.width, size.height);

            if (rect.containsPoint(locationInNode)) {
                GameController::handlePlayFieldCardClick(cardModel.getUid());
                return true;
            }
            return false;
            };

        Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, cardView);

        // 添加到界面
        cardModel.setZOrder(order);
        playFieldLayer->addChild(cardView, order++);
        

        _cardViews[cardModel.getUid()] = cardView;
    }

    setLayerOrder();
    return true;
}

void PlayFieldController::setLayerOrder()
{
    for (auto& cardModel : _playFieldCards) {
        if (isCardCovered(cardModel)) {
            cardModel.setFaceUp(false);
        }
        else {
            _cardViews[cardModel.getUid()]->enableHoverEffect(true);
        }
    }
}

bool PlayFieldController::isCardCovered(CardModel& targetCard) {
    for (auto& otherCard : _playFieldCards) {
        if (otherCard.getUid() == targetCard.getUid()) continue;
        if (otherCard.getZOrder() < targetCard.getZOrder()) continue;
        if (otherCard.getIsMatched()) continue;  // 已消除的不算

        // 判断是否覆盖：
        // 你可以根据坐标判断：如果 Y 比目标牌大 && X 距离很近，说明“压住”
        float dx = std::abs(otherCard.getPosition().x - targetCard.getPosition().x);
        float dy = std::abs(otherCard.getPosition().y - targetCard.getPosition().y);

        const float kHeight = targetCard.getBoundingBox().size.height;
        const float kWidth = targetCard.getBoundingBox().size.width;

        if (dy < kHeight && dx < kWidth) { 
            targetCard.coverBy.insert(&otherCard);
            otherCard.covered.insert(&targetCard);
        }
    }
    if (!targetCard.coverBy.empty()) return true;
    return false;
}

void PlayFieldController::onCardClick(int cardId, GameView* gameView, UndoManager* undoManager) 
{
    // 1. 查找该卡牌是否存在于当前控制器中
    auto it = _cardViews.find(cardId);
    if (it == _cardViews.end()) {
        CCLOG("onCardClick: cardId %d not found in playfield", cardId);
        return;
    }
    CardView* cardView = it->second;

    // 2. 查找模型数据
    auto modelIt = std::find_if(_playFieldCards.begin(), _playFieldCards.end(),
        [cardId](CardModel& card) {
            return card.getUid() == cardId;
        });
    if (modelIt == _playFieldCards.end()) {
        CCLOG("onCardClick: CardModel for cardId %d not found", cardId);
        return;
    }
    CardModel& model = *modelIt;

    // 3. 判断是否正面朝上 & 未匹配
    if (!model.getFaceUp() || model.getIsMatched()) {
        cardView->runAction(AnimationUtils::createShakeAction());
        CCLOG("onCardClick: cardId %d not clickable", cardId);
        return;
    }

    // 4. 判断是否匹配 stack 顶部
    auto topStackCard = GameController::getStackController()->getCurrentCard();
    if (!CardMatchUtil::canMatch(model, *topStackCard)) {
        cardView->runAction(AnimationUtils::createShakeAction());
        CCLOG("onCardClick: cardId %d not matchable", cardId);
        return;
    }

    // 5. 保存 Undo 状态
    undoManager->pushState(&model, cardView, topStackCard);
    cardView->stopAllActions();    // 防止动画叠加影响
    cardView->setScale(1.0f);
    cardView->setHighlight(false);
    cardView->enableHoverEffect(false);
    
    
    // 6. 移动卡牌
    // 获取当前在世界坐标系中的位置
    Vec2 worldPos = cardView->getParent()->convertToWorldSpace(cardView->getPosition());
    // 先 retain 防止被释放
    cardView->retain();
    // 从旧父节点中移除
    cardView->removeFromParent();
    // 将精灵添加到新父节点中
    gameView->getStackLayer()->addChild(cardView, GameController::getStackController()->zOrder++);
    // 将世界坐标转换为新父节点的本地坐标
    Vec2 newPos = gameView->getStackLayer()->convertToNodeSpace(worldPos);
    cardView->setPosition(newPos);
    // 动画移动到 stack 的“手牌区域”位置
    Vec2 handPos = GameController::getStackController()->getHandPos();  
    cardView->runAction(MoveTo::create(0.3f, handPos));
    // 释放 retain
    cardView->release();

    // 7. 更新 view
    hasMovedCount++;
    GameController::getStackController()->updateCurrentCard(&model);
    model.setIsMatched(true);
    for (auto card : model.covered) {
        card->coverBy.erase(&model);
        if (card->coverBy.empty()) {
            card->setFaceUp(true);
            _cardViews[card->getUid()]->enableHoverEffect(true);
        }
    }
    _cardViews.erase(cardId);
    

    // 8. 通知 GameController 更新状态或胜利判定
    if(hasMovedCount == _playFieldCards.size())
        GameController::checkGameProgress(); 
}


void PlayFieldController::undoPlayFieldCard(CardModel* cardModel, CardView* cardView)
{
    _cardViews[cardModel->getUid()] = cardView;
    for (auto card : cardModel->covered) {
        if (card->coverBy.empty()) {
            card->setFaceUp(false);
            _cardViews[card->getUid()]->enableHoverEffect(false);
        }
        card->coverBy.insert(cardModel);
    }
    hasMovedCount--;
    GameController::getStackController()->zOrder--;
    
}