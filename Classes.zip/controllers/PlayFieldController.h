﻿#pragma once

#include "models/GameModel.h"
#include "views/CardView.h"
#include "views/GameView.h"
#include "managers/undoManager.h"
#include "cocos2d.h"

/// @brief 控制游戏桌面中卡牌的展示与交互逻辑
class PlayFieldController {
public:
    //PlayFieldController();

    /// 初始化控制器，绑定 GameModel 数据
    bool init(const std::vector<CardModel>& playFieldCards);

    /// 初始化视图层，将 CardView 添加到 playFieldLayer 上
    bool initView(cocos2d::Node* playFieldLayer);

    // 初始化层级关系
    void setLayerOrder();
    bool PlayFieldController::isCardCovered(CardModel& targetCard);

    /// 响应用户点击卡牌
    void onCardClick(int cardId, GameView* gameView, UndoManager* undoManager);

    // 撤销事件
    void undoPlayFieldCard(CardModel* cardModel, CardView* cardView);

private:
    std::vector<CardModel> _playFieldCards;       ///< 引用 GameModel，不负责释放
    std::unordered_map<int, CardView*> _cardViews; ///< 卡牌ID到视图映射

    int hasMovedCount = 0;
};