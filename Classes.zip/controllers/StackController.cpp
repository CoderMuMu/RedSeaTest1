﻿#include "StackController.h"
#include "models/GameModel.h"
#include "GameController.h"

USING_NS_CC;

bool StackController::init(const std::vector<CardModel>& stackCards) 
{
    _stackCards = stackCards;
    _currentIndex = _stackCards.size() - 1;

    if (!_stackCards.empty()) {
        _currentCard = &_stackCards[stackCards.size()-1];
    }
    else {
        _currentCard = nullptr;
    }

    // 初始化内部状态，如布局等
    for (const auto& card : _stackCards) {
        CCLOG("Init Stack Card: id=%d, face=%d, suit=%d", card.getUid(), card.getFace(), card.getSuit());
    }

    return true;
}

bool StackController::initView(cocos2d::Layer* parentLayer)
{
    if (!parentLayer || _stackCards.empty()) return false;

    const float offsetX = 40.0f; // 每张牌的水平偏移
    const Vec2 basePos = Vec2(450-offsetX*(_stackCards.size()-2), parentLayer->getContentSize().height / 2); // 第一张牌位置（你可以调整）
    _handPos = Vec2(700, parentLayer->getContentSize().height / 2);

    for (size_t i = 0; i < _stackCards.size(); ++i) {
        auto& card = _stackCards[i];

        // 创建sprite对象
        auto cardView = CardView::createFromModel(card);
        if (!cardView) continue;

        // 设置位置
        Vec2 pos = (i == 0) ? basePos : basePos + Vec2(offsetX * i, 0);
        if (i == _stackCards.size() - 1) pos = _handPos;

        cardView->setPosition(pos);
        cardView->setTag(card.getUid());
        parentLayer->addChild(cardView, 0);
        card.setZOrder(0);

        _deckViewStack.push(cardView);

        auto boundingBox = cardView->getBoundingBox();
        card.setBoundingBox(boundingBox);

        
        auto listener = EventListenerTouchOneByOne::create();
        listener->setSwallowTouches(true);
        listener->onTouchBegan = [=, &card](Touch* touch, Event* event) {
            auto location = cardView->convertToNodeSpace(touch->getLocation());
            auto size = cardView->getContentSize();
            Rect rect(0, 0, size.width, size.height);

            if (rect.containsPoint(location)) {
                GameController::handleStackCardClick(card.getUid());
                return true;
            }
            return false;
        };

        Director::getInstance()->getEventDispatcher()
            ->addEventListenerWithSceneGraphPriority(listener, cardView);
    }
    // 设置第一张翻开牌
    _stackCards.at(_stackCards.size() - 1).setFaceUp(true);
    _stackCards.at(_stackCards.size() - 1).setIsMatched(true);
    _deckViewStack.pop();

    return true;
}

void StackController::drawNextCard(int cardId, GameView* gameView, UndoManager* undoManager)
{
    // 1. 查找该卡牌是否存在于当前牌堆顶部
    if (_deckViewStack.empty()) {

        CCLOG("drawNextCard: cardId %d not clickable", cardId);
        return;
    }
    CardView* cardView = _deckViewStack.top();
    if (cardView == nullptr || cardView->getCardId() != cardId || _stackCards.at(_currentIndex-1).getUid() != cardId) {
        CCLOG("drawNextCard: cardId %d not clickable", cardId);
        return;
    }

    // 2. 查找模型数据
    auto modelIt = std::find_if(_stackCards.begin(), _stackCards.end(),
        [cardId](CardModel& card) {
            return card.getUid() == cardId;
        });
    if (modelIt == _stackCards.end()) {
        CCLOG("drawNextCard: CardModel for cardId %d not found", cardId);
        return;
    }
    CardModel& model = *modelIt;

    // 5. 保存 Undo 状态
    undoManager->pushState(&model, cardView, _currentCard);

    // 6. 移动卡牌
    // 动画移动到 stack 的“手牌区域”位置
    cardView->runAction(MoveTo::create(0.3f, _handPos));
    cardView->setZOrder(zOrder++);

    // 7. 更新 view
    _deckViewStack.pop();
    updateCurrentCard(&model);
    model.setIsMatched(true);
    model.setFaceUp(true);
    _currentIndex--;
    
}

void StackController::undoStackCard(CardModel* cardModel, CardView* cardView)
{
    _currentIndex++;
    _deckViewStack.push(cardView);
    zOrder--;
}

CardModel* StackController::getCurrentCard() const {
    return _currentCard;
}

cocos2d::Vec2 StackController::getHandPos() const
{
    return _handPos;
}

void StackController::updateCurrentCard(CardModel* cardModel)
{
    _currentCard = cardModel;
}