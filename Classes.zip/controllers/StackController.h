﻿#pragma once

#include "models/GameModel.h"
#include "views/CardView.h"
#include "views/GameView.h"
#include "managers/UndoManager.h"
#include "cocos2d.h"

/// @brief 控制卡堆区（用于抽牌的区域）的逻辑与显示
class StackController {
public:
    //StackController();

    /// 初始化控制器，绑定 GameModel 数据
    bool init(const std::vector<CardModel>& stackCards);

    /// 初始化视图，将抽牌堆显示到对应 UI 层
    bool initView(cocos2d::Layer* parentLayer);

    ///// 抽取下一张牌
    void drawNextCard(int cardId, GameView* gameView, UndoManager* undoManager);

    // 获得当前手牌
    CardModel* getCurrentCard() const;
    cocos2d::Vec2 getHandPos() const;

    // 更新当前手牌
    void updateCurrentCard(CardModel * cardModel);

    // 撤销stackCard
    void undoStackCard(CardModel* cardModel, CardView* cardView);

    int zOrder = 1;
private:
    std::vector<CardModel> _stackCards;
    CardModel* _currentCard = nullptr;
    int _currentIndex = 0;
    
    std::stack<CardView*> _deckViewStack;    ///< 抽牌堆视图（叠牌）
    cocos2d::Vec2 _handPos;
};

